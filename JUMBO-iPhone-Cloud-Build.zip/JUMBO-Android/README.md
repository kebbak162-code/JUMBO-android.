# JUMBO Android starter — Firebase connected

Firebase Android configuration for project `jumbo-bd75e` is included at `app/google-services.json`.

## Finish Firebase setup
1. In Firebase Console, select project `jumbo-bd75e`.
2. Authentication → Sign-in method → enable **Phone**.
3. Authentication settings → configure allowed SMS regions (include Gambia if appropriate), quotas, and app verification.
4. Create a Cloud Firestore database.
5. Publish the contents of `firestore.rules` in Firestore Rules.
6. Open this folder in Android Studio, sync Gradle, then Build > Build Bundle(s) / APK(s) > Build APK(s).

## Current scope
- Phone number + SMS OTP authentication.
- Firestore user profile registration.
- Starter one-to-one text chat lookup by registered phone number.
- Real-time Firestore message listener.

## Before public launch
This is an early starter, not a production-ready WhatsApp replacement. Have the Firestore rules and data model reviewed; add push notifications, contact discovery with consent, blocking/reporting, account deletion, abuse prevention, media uploads, delivery/read receipts, privacy policy, and end-to-end encryption if required. Test using two separate phones/accounts. Firebase SMS usage may have quotas or charges.


## Build in the cloud from an iPhone
A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`.
After this project is committed to a GitHub repository:
1. Open the repository in Safari and choose the **Actions** tab.
2. Select **Build JUMBO Android APK**.
3. Tap **Run workflow** (or push a commit to `main` to trigger it).
4. Open the completed run and download the `JUMBO-debug-apk` artifact.
