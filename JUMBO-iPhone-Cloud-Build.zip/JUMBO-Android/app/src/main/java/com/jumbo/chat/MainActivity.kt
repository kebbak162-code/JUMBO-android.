package com.jumbo.chat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.util.concurrent.TimeUnit

private val Gold = Color(0xFFD4AF37)
private val DeepBlack = Color(0xFF101010)
private val Panel = Color(0xFF1C1C1C)
private val SoftWhite = Color(0xFFF5F1E5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        currentActivityHolder = this
        FirebaseApp.initializeApp(this)
        setContent { JumboApp() }
    }
}

data class ChatPreview(val id: String, val title: String, val lastMessage: String)

@Composable
fun JumboApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    var signedIn by remember { mutableStateOf(auth.currentUser != null) }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var pendingPhone by remember { mutableStateOf("") }
    var selectedChat by remember { mutableStateOf<ChatPreview?>(null) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold, onPrimary = DeepBlack,
            background = DeepBlack, surface = Panel,
            onBackground = SoftWhite, onSurface = SoftWhite
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = DeepBlack) {
            when {
                !signedIn && verificationId == null -> PhoneLogin(
                    onSendCode = { phone, onResult ->
                        pendingPhone = phone
                        val options = PhoneAuthOptions.newBuilder(auth)
                            .setPhoneNumber(phone)
                            .setTimeout(60L, TimeUnit.SECONDS)
                            .setActivity(currentActivityHolder)
                            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                                override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                                    auth.signInWithCredential(credential).addOnSuccessListener { onResult(null) }
                                        .addOnFailureListener { onResult(it.localizedMessage ?: "Sign-in failed") }
                                }
                                override fun onVerificationFailed(e: com.google.firebase.FirebaseException) {
                                    onResult(e.localizedMessage ?: "Could not send verification code")
                                }
                                override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                                    verificationId = id
                                    onResult(null)
                                }
                            }).build()
                        PhoneAuthProvider.verifyPhoneNumber(options)
                    }
                )
                !signedIn && verificationId != null -> OtpScreen(
                    phone = pendingPhone,
                    onVerify = { code, onResult ->
                        val credential = PhoneAuthProvider.getCredential(verificationId!!, code)
                        auth.signInWithCredential(credential)
                            .addOnSuccessListener { signedIn = true; onResult(null) }
                            .addOnFailureListener { onResult(it.localizedMessage ?: "Invalid code") }
                    },
                    onBack = { verificationId = null }
                )
                selectedChat == null -> HomeScreen(
                    phone = auth.currentUser?.phoneNumber ?: pendingPhone,
                    db = db,
                    onOpenChat = { selectedChat = it },
                    onSignOut = { auth.signOut(); signedIn = false; verificationId = null }
                )
                else -> ChatScreen(
                    chat = selectedChat!!,
                    uid = auth.currentUser?.uid ?: "",
                    db = db,
                    onBack = { selectedChat = null }
                )
            }
        }
    }
}

// The activity is supplied from the Compose context in the production build.
private lateinit var currentActivityHolder: ComponentActivity

@Composable
private fun PhoneLogin(onSendCode: (String, (String?) -> Unit) -> Unit) {
    var phone by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("JUMBO", color = Gold, fontSize = 42.sp, fontWeight = FontWeight.ExtraBold)
        Text("Connect • Chat • Share", color = SoftWhite.copy(alpha = .7f))
        Spacer(Modifier.height(44.dp))
        Text("Welcome to JUMBO", color = SoftWhite, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Enter your phone number to get started.", color = SoftWhite.copy(alpha = .7f))
        Spacer(Modifier.height(22.dp))
        OutlinedTextField(
            value = phone, onValueChange = { phone = it; error = null },
            label = { Text("Phone number, including country code") },
            placeholder = { Text("+220XXXXXXXX") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true, modifier = Modifier.fillMaxWidth(),
            colors = goldFieldColors()
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp)) }
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = {
                if (!phone.trim().startsWith("+") || phone.trim().length < 8) {
                    error = "Enter a valid number with country code, e.g. +220XXXXXXXX"
                } else {
                    busy = true
                    onSendCode(phone.trim()) { result -> busy = false; error = result }
                }
            },
            enabled = !busy, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepBlack)
        ) { Text(if (busy) "Sending..." else "Send verification code", fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(18.dp))
        Text("By continuing, you agree to use JUMBO responsibly.", color = SoftWhite.copy(alpha = .45f), fontSize = 12.sp)
    }
}

@Composable
private fun OtpScreen(phone: String, onVerify: (String, (String?) -> Unit) -> Unit, onBack: () -> Unit) {
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Gold); Text("Back", color = Gold) }
        Text("Verify your number", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Enter the SMS code sent to $phone", color = SoftWhite.copy(alpha = .75f))
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = code, onValueChange = { code = it.filter(Char::isDigit).take(6) },
            label = { Text("6-digit code") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true, modifier = Modifier.fillMaxWidth(), colors = goldFieldColors()
        )
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            busy = true
            onVerify(code) { result -> busy = false; error = result }
        }, enabled = code.length == 6 && !busy, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepBlack)
        ) { Text(if (busy) "Verifying..." else "Verify and continue") }
    }
}

@Composable
private fun HomeScreen(
    phone: String, db: FirebaseFirestore,
    onOpenChat: (ChatPreview) -> Unit, onSignOut: () -> Unit
) {
    var chats by remember { mutableStateOf(listOf<ChatPreview>()) }
    var newPhone by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val uid = FirebaseAuth.getInstance().currentUser?.uid ?: ""

    LaunchedEffect(uid, phone) {
        if (uid.isNotBlank() && phone.isNotBlank()) {
            db.collection("users").document(uid).set(
                mapOf("phoneNumber" to phone, "updatedAt" to System.currentTimeMillis()),
                com.google.firebase.firestore.SetOptions.merge()
            )
        }
    }

    DisposableEffect(uid) {
        val registration = db.collection("users").document(uid).collection("chats")
            .addSnapshotListener { snapshot, _ ->
                chats = snapshot?.documents?.map {
                    ChatPreview(it.id, it.getString("title") ?: it.id, it.getString("lastMessage") ?: "Start chatting")
                } ?: emptyList()
            }
        onDispose { registration.remove() }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("JUMBO", color = Gold, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text(phone, color = SoftWhite.copy(alpha = .65f), fontSize = 12.sp)
            }
            TextButton(onClick = onSignOut) { Text("Sign out", color = Gold) }
        }
        Column(Modifier.padding(16.dp)) {
            Text("Start a conversation", color = SoftWhite, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = newPhone, onValueChange = { newPhone = it },
                label = { Text("Friend's phone number (+country code)") },
                modifier = Modifier.fillMaxWidth(), singleLine = true, colors = goldFieldColors()
            )
            Button(onClick = {
                val number = newPhone.trim()
                if (!number.startsWith("+")) error = "Use the full number with country code."
                else {
                    db.collection("users").whereEqualTo("phoneNumber", number).limit(1).get()
                        .addOnSuccessListener { result ->
                            val peer = result.documents.firstOrNull()
                            if (peer == null) {
                                error = "That number is not registered on JUMBO yet."
                            } else {
                                val peerUid = peer.id
                                if (peerUid == uid) {
                                    error = "You cannot start a chat with your own number."
                                } else {
                                    val chatId = listOf(uid, peerUid).sorted().joinToString("_")
                                    val members = listOf(uid, peerUid)
                                    val batch = db.batch()
                                    batch.set(
                                        db.collection("chats").document(chatId),
                                        mapOf("members" to members, "createdAt" to System.currentTimeMillis()),
                                        com.google.firebase.firestore.SetOptions.merge()
                                    )
                                    batch.set(
                                        db.collection("users").document(uid).collection("chats").document(chatId),
                                        mapOf("title" to number, "peerUid" to peerUid, "lastMessage" to "Start chatting")
                                    )
                                    batch.set(
                                        db.collection("users").document(peerUid).collection("chats").document(chatId),
                                        mapOf("title" to (FirebaseAuth.getInstance().currentUser?.phoneNumber ?: "JUMBO user"),
                                            "peerUid" to uid, "lastMessage" to "Start chatting")
                                    )
                                    batch.commit()
                                        .addOnSuccessListener { onOpenChat(ChatPreview(chatId, number, "Start chatting")) }
                                        .addOnFailureListener { error = it.localizedMessage ?: "Could not create chat." }
                                }
                            }
                        }.addOnFailureListener { error = it.localizedMessage ?: "Could not find that user." }
                }
            }, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = DeepBlack)) {
                Text("New chat")
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Spacer(Modifier.height(16.dp))
            Text("CHATS", color = Gold, fontWeight = FontWeight.Bold)
        }
        LazyColumn {
            items(chats) { chat ->
                Column(Modifier.fillMaxWidth().clickable { onOpenChat(chat) }.padding(horizontal = 18.dp, vertical = 14.dp)) {
                    Text(chat.title, color = SoftWhite, fontWeight = FontWeight.SemiBold)
                    Text(chat.lastMessage, color = SoftWhite.copy(alpha = .55f), fontSize = 13.sp)
                }
                HorizontalDivider(color = Gold.copy(alpha = .18f))
            }
        }
    }
}

@Composable
private fun ChatScreen(chat: ChatPreview, uid: String, db: FirebaseFirestore, onBack: () -> Unit) {
    var messages by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    var draft by remember { mutableStateOf("") }
    val chatRef = remember(chat.id) { db.collection("chats").document(chat.id).collection("messages") }

    DisposableEffect(chat.id) {
        val registration = chatRef.orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, _ ->
                messages = snapshot?.documents?.map {
                    (it.getString("senderId") ?: "") to (it.getString("text") ?: "")
                } ?: emptyList()
            }
        onDispose { registration.remove() }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(Panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Gold) }
            Text(chat.title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp)) {
            items(messages) { (sender, message) ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (sender == uid) Arrangement.End else Arrangement.Start) {
                    Text(message, color = if (sender == uid) DeepBlack else SoftWhite,
                        modifier = Modifier.padding(vertical = 4.dp).background(
                            if (sender == uid) Gold else Panel, RoundedCornerShape(14.dp)
                        ).padding(12.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Message") }, colors = goldFieldColors(), maxLines = 4)
            IconButton(onClick = {
                val text = draft.trim()
                if (text.isNotEmpty()) {
                    chatRef.add(hashMapOf("senderId" to uid, "text" to text, "createdAt" to System.currentTimeMillis()))
                    draft = ""
                }
            }) { Icon(Icons.Default.Send, null, tint = Gold) }
        }
    }
}

@Composable
private fun goldFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Gold, unfocusedBorderColor = Gold.copy(alpha = .45f),
    focusedLabelColor = Gold, cursorColor = Gold,
    focusedTextColor = SoftWhite, unfocusedTextColor = SoftWhite
)
